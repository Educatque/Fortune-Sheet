export const INVALID_PARAMS = new Error("invalid params");
export const SHEET_NOT_FOUND = new Error("sheet not found");
